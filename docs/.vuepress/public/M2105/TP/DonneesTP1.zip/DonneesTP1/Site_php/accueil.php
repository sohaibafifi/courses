<?php include("entete.html"); ?>

<div id="navcorps">
<?php
@setlocale(LC_TIME, 'fr_FR');

function afficheDate($jl, $j, $m, $a, $h, $mn, $semaine,$ja){
	if($h < 18){
   		echo "<p> Bonjour tout le monde !</p> ";
	}else{
		echo "<p> Bonsoir tout le monde !</p> ";
	}
	echo "<p>Nous sommes le $jl $j $m $a, jour numéro $ja de l'année, semaine $semaine. Il est $h h $mn.</p>";

	if($h < 12){
   		echo "<p> Bonne journée !</p>";
	}else if($h < 17){
   		echo "<p> Bon après midi !</p>";
	}else if($h < 21){
		echo "<p> Bonne soirée !</p>";
	}else {
		echo "<p> Bonne nuit </p>";
	}
}

	$jourL = strftime("%A");
	$jour = strftime("%d");
	$mois = strftime("%B");
	$annee = strftime("%Y");

	/*$jour = date("d");$mois = date("m");$annee = date("Y");*/

	$heure = date("H");
	$minute = date("i");

	$numJourSemaine = date("w"); // 1 pour lundi
	$numJourAnnee = date("z");  // 0 pour le 1er Janvier
	$numSemaine = date("W");

	afficheDate($jourL,$jour,$mois,$annee,$heure,$minute,$numSemaine,$numJourAnnee);

?>
</div>

<?php include("pieddepage.html"); ?>
