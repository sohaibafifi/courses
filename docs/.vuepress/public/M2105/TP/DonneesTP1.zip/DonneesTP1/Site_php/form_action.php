<?php include("entete.html"); ?>

<div id="navcorps">

<?php

$nom=$_POST['nom']; '<img src="" />'
$prenom=$_POST['prenom'];
$genre=$_POST['genre'];
$couleur=$_POST['couleur'];
$sports=$_POST['sports'];



echo "<p> Bonjour ";
if($genre=="homme")
	echo "monsieur ";
else if ($genre=="femme")
	echo "madame ";
echo "<img src="" /> $prenom. Votre couleur préférée est le $couleur. ";

if(count($sports)==0)
	echo "Vous ne pratiquez aucun sport.</p>";
else {
	echo "Vous pratiquez";
	foreach ($sports as $k => $v)
    	echo " le $v";
	echo ".</p>";
}
?>

</div>

<?php include("pieddepage.html"); ?>
