<?php include("entete.html"); ?>

<div id="navcorps">

<h1>Convertisseur Euros/Dollars</h1>

 <?php
 	$k=substr(strstr(file_get_contents("https://www.google.com/finance"),'EUR/USD'),28,6);
	if ($_POST['sens']==to_dol){   
	   $init="euros";
	   $fin="dollars";
	 }
	 else {
	   $k=1/$k;
	   $init="dollars";
	   $fin="euros";
	 }
	 $res=$k*$_POST['val'];
	 echo "<p>".$_POST['val']." $init valent $res $fin </p>";
 ?>	

</div>

<?php include("pieddepage.html"); ?>
