<?php include("entete.html"); ?>

<div id="navcorps">

<h1>Convertisseur Euros/Dollars</h1>
	
<form action="convert_action.php" method="post">
	<p>Euros vers Dollars : <input type="radio" name="sens" id="sens" value="to_dol" /></p>
	<p>Dollars vers Euros : <input type="radio" name="sens" id="sens" value="to_eur" /></p>
	<p>Valeur : <input type="text" name="val" id="val"/></p>
	<p>
	<input type="submit" value="Valider" />
	<input type="reset" value="Reset"/>
	</p>
</form>

</div>

<?php include("pieddepage.html"); ?>
