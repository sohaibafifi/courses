<?php
@session_start();
/* Traitement de la page : ajout d'un genre */
/* 1.Récupération des informations issues du formulaire */
/* Tous les genres commencent par un lettre en majuscule suivi de minuscules */
$err="";
$genre=ucfirst(strtolower($_POST['genre']));
if($genre==""){
    $err="Veuillez svp préciser le nom du genre";
}else{
    // test si le genre n'est pas déjà dans la base
    include('connexion.php');
    $res=pg_query($conn,"SELECT genre FROM genre where genre like '".$genre."';");
    if(pg_num_rows($res)>0) $err="Genre déjà présent";
    pg_close($conn);
}

/* 2.Stockage des informations dans la session */
$_SESSION['genre']=$_POST['genre'];
$_SESSION['err']=$_POST['err'];

/* 3.Renvoie vers les pages adéquates */

if($err==""){
    $sql="INSERT INTO genre(genre) VALUES ";
    $sql.="('$genre');";

    include('connexion.php');

    pg_query($conn, $sql);
    pg_close($conn);
    // Si on voulait vider le contenu de la session :
    //session_destroy();
    //unset($_SESSION);
    // Mais on veut transmettre l'information suivante :
    $_SESSION['msgN']="Ajout effectué";
    $_SESSION['nom']="";
    $_SESSION['prenom']="";
    $_SESSION['annee']="";
    $_SESSION['mois']="";
    $_SESSION['jour']="";
    $_SESSION['sexe']="";
    $_SESSION['err']="";
    header("Location: ajout_genre.php");
    exit();
}else{
    $_SESSION['msgN']="";
    header("Location: ajout_genre.php");
    exit();
}
?>