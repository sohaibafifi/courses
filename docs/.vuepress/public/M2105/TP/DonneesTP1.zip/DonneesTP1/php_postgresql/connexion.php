<?php
$conn = pg_connect("host= dbname= user= password=");
pg_query($conn, "SET SEARCH_PATH=film,PG_CATALOG");
