<!DOCTYPE html>
<html lang="fr">

    <head>
        <meta charset="utf8" />
        <title> Liste des genres </title>
        <link rel="stylesheet" href="film.css"/>
    </head>

    <body>

    <?php

    include('connexion.php');

    $result = pg_query($conn, "SELECT * FROM genre");

    $nombreLignes = pg_num_rows($result);
    $nombreColonnes = pg_num_fields($result);

?>

<!-- Méthode n°1 -->
<table>
<caption> Liste des genres (Méthode n°1) </caption>
<?php
for($i = 0; $i < $nombreLignes; $i++){
    echo "<tr>";
    for($j = 0; $j < $nombreColonnes; $j++)
        echo "<td>".pg_result($result, $i, $j)."</td>";
    echo "</tr>\n";
}
?>
</table>

<!-- Méthode n°2 -->
<table>
<caption> Liste des genres (Méthode n°2) </caption>
<?php
while($ligne = pg_fetch_array($result)){
    echo "<tr>";
    for($i = 0; $i < $nombreColonnes; $i++)
        echo "<td>".$ligne[$i]."</td>";
    echo "</tr>\n";
}
?>
</table>

</body>
</html>