<!DOCTYPE html>
<html lang="fr">

    <head>
        <meta charset="utf-8" />
        <title> Liste des genres </title>
    </head>

    <body>

    <?php
    $conn = pg_connect("host= dbname= user= password=");
    pg_query($conn, "SET SEARCH_PATH=film,PG_CATALOG");

    $result = pg_query($conn, "SELECT genre FROM genre");

    echo "<p> Liste des genres : </p>";
    echo "<ul>";
    while($ligne = pg_fetch_array($result)){
        echo "<li>".$ligne[0]."</li>\n";
    }
    echo "</ul>\n";

    pg_close($conn);
    ?>

</body>
</html>
