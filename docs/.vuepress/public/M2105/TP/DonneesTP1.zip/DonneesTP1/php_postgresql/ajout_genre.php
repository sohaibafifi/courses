<?php
@session_start();
?>

<!DOCTYPE html>
<html lang="fr">

    <head>
        <meta charset="utf8" />
        <title> Liste des genres </title>
        <link rel="stylesheet" href="film.css"/>
    </head>

    <body>

    <?php

    include('connexion.php');

    $result = pg_query($conn, "SELECT * FROM genre");

    $nombreLignes = pg_num_rows($result);
    $nombreColonnes = pg_num_fields($result);

?>

<!-- Méthode n°1 -->
<table>
<caption> Liste des genres (Méthode n°1) </caption>
<?php
for($i = 0; $i < $nombreLignes; $i++){
    echo "<tr>";
    for($j = 0; $j < $nombreColonnes; $j++)
        echo "<td>".pg_result($result, $i, $j)."</td>";
    echo "</tr>\n";
}
?>
</table>

<!-- Méthode n°2 -->
<table>
<caption> Liste des genres (Méthode n°2) </caption>
<?php
while($ligne = pg_fetch_array($result)){
    echo "<tr>";
    for($i = 0; $i < $nombreColonnes; $i++)
        echo "<td>".$ligne[$i]."</td>";
    echo "</tr>\n";
}
?>
</table>

<?php
if(isset($_SESSION['err']) && $_SESSION['err']!="")
    echo "<div id=\"erreur\"> <p> Erreur : ".$_SESSION['err']."</p></div>";

if(isset($_SESSION['msgN']) && $_SESSION['msgN']!="")
    echo "<div id=\"notification\"> <p>".$_SESSION['msgN']."</p></div>";
?>

<form method="post" action="ajout_genre_action.php">
     <fieldset>
          <legend> Ajout d'un nouveau genre </legend>
          <label for="genre">Genre</label> :
          <input type="text"  name="genre" id="genre"
                 value="<?php if(isset($_SESSION['genre'])) echo $_SESSION['genre'];?>" />
          <input type="submit" name="ajoutgenre"
                 id="ajoutgenre" value=" Ajout "/>
     </fieldset>
</form>

</body>
</html>