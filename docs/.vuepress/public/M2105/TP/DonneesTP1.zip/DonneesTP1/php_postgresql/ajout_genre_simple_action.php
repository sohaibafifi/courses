<?php
$genre=ucfirst(strtolower($_POST['genre']));
$sql="INSERT INTO genre(genre) VALUES ";
$sql.="('$genre');";

include('connexion.php');

pg_query($conn, $sql);
pg_close($conn);

header("Location: ajout_genre_simple.php");
exit();
?>
